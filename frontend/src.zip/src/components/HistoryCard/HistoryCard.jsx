import { FileCode2 } from "lucide-react";

function HistoryCard({ review }) {

    const formattedDate = new Date(review.reviewedAt).toLocaleString();

    return (

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">

            <div className="flex justify-between items-start">

                <div>

                    <div className="flex items-center gap-2">

                        <FileCode2 size={18} />

                        <h2 className="font-semibold">

                            {review.fileName}

                        </h2>

                    </div>

                    <p className="text-sm text-slate-400 mt-2">

                        {formattedDate}

                    </p>

                </div>

                <div className="text-sm bg-slate-800 px-3 py-1 rounded">

                    Score : {review.score}
                </div>

            </div>

            <hr className="border-slate-800 my-4"/>

            <div className="text-slate-300 whitespace-pre-wrap text-sm leading-6 max-h-56 overflow-auto">

                {review.review}

            </div>

        </div>

    );

}

export default HistoryCard;