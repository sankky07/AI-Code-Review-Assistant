import { FileCode2, CircleAlert, CircleCheck, TriangleAlert } from "lucide-react";
import { motion } from "framer-motion";

function ReviewCard({ review }) {

    const parts = review.split("\n\n");

    const title = parts[0].replace("FILE : ", "");

    const content = parts.slice(1).join("\n\n");

    let status = "Good";
    let color = "text-green-400";
    let icon = <CircleCheck size={18} />;

    if (
        content.toLowerCase().includes("warning") ||
        content.toLowerCase().includes("consider")
    ) {
        status = "Warning";
        color = "text-yellow-400";
        icon = <TriangleAlert size={18} />;
    }

    if (
        content.toLowerCase().includes("critical") ||
        content.toLowerCase().includes("error")
    ) {
        status = "Critical";
        color = "text-red-400";
        icon = <CircleAlert size={18} />;
    }

    return (

        <motion.div
            whileHover={{ y: -5 }}
            transition={{ duration: 0.2 }}
            className="bg-slate-900 border border-slate-800 rounded-3xl p-7 hover:border-blue-500 hover:shadow-blue-500/20 hover:shadow-xl"
        >

            <div className="flex justify-between items-center">

                <div className="flex items-center gap-3">

                    <FileCode2 className="text-blue-400"/>

                    <h2 className="text-2xl font-bold">

                        {title}

                    </h2>

                </div>

                <div className={`flex items-center gap-2 ${color}`}>

                    {icon}

                    {status}

                </div>

            </div>

            <pre className="mt-6 whitespace-pre-wrap text-slate-300 leading-8">

                {content}

            </pre>

        </motion.div>

    );

}

export default ReviewCard;