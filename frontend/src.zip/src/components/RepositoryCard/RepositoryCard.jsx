import { motion } from "framer-motion";
import {
    ArrowRight,
    Lock,
    Globe,
    GitBranch,
} from "lucide-react";

function RepositoryCard({
                            name,
                            language,
                            description,
                            htmlUrl,
                            branch,
                            isPrivate,
                            onReview
                        }) {

    const languageColor = {

        Java: "bg-orange-500/20 text-orange-400",

        JavaScript: "bg-yellow-500/20 text-yellow-400",

        TypeScript: "bg-blue-500/20 text-blue-400",

        Python: "bg-green-500/20 text-green-400",

        HTML: "bg-red-500/20 text-red-400",

        CSS: "bg-cyan-500/20 text-cyan-400",

        React: "bg-sky-500/20 text-sky-400"

    };

    return (

        <motion.div

            whileHover={{
                y: -8,
                scale: 1.02
            }}

            transition={{ duration: 0.2 }}

            className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-xl hover:border-blue-500 hover:shadow-blue-500/20 hover:shadow-2xl"

        >

            <div className="flex justify-between items-start">

                <div>

                    <h2 className="text-2xl font-bold">

                        {name}

                    </h2>

                    <p className="text-slate-400 mt-3">

                        {description || "No description available."}

                    </p>

                </div>

                <a

                    href={htmlUrl}

                    target="_blank"

                    rel="noreferrer"

                >

                    <GitBranch className="hover:text-blue-400"/>

                </a>

            </div>

            <div className="flex flex-wrap gap-3 mt-6">

                <span className="flex items-center gap-2 bg-slate-800 px-3 py-2 rounded-xl">

                    {isPrivate ?

                        <Lock size={16}/>

                        :

                        <Globe size={16}/>

                    }

                    {isPrivate ? "Private" : "Public"}

                </span>

                <span className="flex items-center gap-2 bg-slate-800 px-3 py-2 rounded-xl">

                    <GitBranch size={16}/>

                    {branch}

                </span>

                <span className={`px-3 py-2 rounded-xl ${languageColor[language] || "bg-slate-800"}`}>

                    {language || "Unknown"}

                </span>

            </div>

            <div className="flex justify-end mt-8">

                <button

                    onClick={onReview}

                    className="bg-blue-600 hover:bg-blue-500 transition rounded-xl px-6 py-3 flex items-center gap-3"

                >

                    Review Repository

                    <ArrowRight size={18}/>

                </button>

            </div>

        </motion.div>

    );

}

export default RepositoryCard;