import { useEffect, useState } from "react";
import {
    LayoutDashboard,
    History,
    LogOut,
    GitBranch
} from "lucide-react";
import { NavLink } from "react-router-dom";
import { getCurrentUser } from "../../services/userService";

function Sidebar() {

    const [user, setUser] = useState(null);

    useEffect(() => {

        loadUser();

    }, []);

    async function loadUser() {

        try {

            const data = await getCurrentUser();

            setUser(data);

        } catch (error) {

            console.error("Failed to load user", error);

        }

    }

    const menuClass = ({ isActive }) =>
        `flex items-center gap-3 px-4 py-3 rounded-xl transition ${
            isActive
                ? "bg-blue-600 text-white"
                : "text-slate-300 hover:bg-slate-800"
        }`;

    return (

        <aside className="w-72 bg-slate-900 border-r border-slate-800 flex flex-col">

            {/* Logo */}

            <div className="p-8 border-b border-slate-800">

                <div className="flex items-center gap-3">

                    <div className="bg-blue-600 p-3 rounded-xl">

                        <GitBranch size={24} />

                    </div>

                    <div>

                        <h1 className="font-bold text-xl">

                            AI Code Review

                        </h1>

                        <p className="text-slate-400 text-sm">

                            Assistant

                        </p>

                    </div>

                </div>

            </div>

            {/* Navigation */}

            <nav className="flex-1 p-6 space-y-3">

                <NavLink
                    to="/dashboard"
                    className={menuClass}
                >
                    <LayoutDashboard size={20} />
                    Dashboard
                </NavLink>

                <NavLink
                    to="/history"
                    className={menuClass}
                >
                    <History size={20} />
                    History
                </NavLink>

            </nav>

            {/* User Section */}

            <div className="border-t border-slate-800 p-6">

                <div className="bg-slate-800 rounded-2xl p-4">

                    <div className="flex items-center gap-3">

                        <img
                            src={
                                user?.avatarUrl ||
                                "https://github.githubassets.com/images/modules/logos_page/GitHub-Mark.png"
                            }
                            alt="Profile"
                            className="w-12 h-12 rounded-full border border-slate-700"
                        />

                        <div>

                            <h3 className="font-semibold">

                                {user?.name || user?.login || "GitHub User"}

                            </h3>

                            <p className="text-slate-400 text-sm">

                                @{user?.login}

                            </p>

                        </div>

                    </div>

                </div>

                <button
                    onClick={() => {
                        window.location.href = "http://localhost:8080/logout";
                    }}
                    className="mt-5 w-full flex justify-center items-center gap-3 bg-red-600 hover:bg-red-500 transition rounded-xl py-3"
                >
                    <LogOut size={18} />
                    Logout
                </button>

            </div>

        </aside>

    );

}

export default Sidebar;