import { useEffect, useState } from "react";
import MainLayout from "../../layouts/MainLayout";
import HistoryCard from "../../components/HistoryCard/HistoryCard";
import { getAllHistory } from "../../services/historyService";
import toast from "react-hot-toast";

function History() {

    const [history, setHistory] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {

        loadHistory();

    }, []);

    async function loadHistory() {

        try {

            const data = await getAllHistory();

            setHistory(data);

        }

        catch (e) {

            console.error(e);

            toast.error("Unable to load history.");

        }

        finally {

            setLoading(false);

        }

    }

    return (

        <MainLayout>

            <div className="max-w-6xl mx-auto p-8">

                <div className="mb-8">

                    <h1 className="text-3xl font-bold">

                        Review History

                    </h1>

                    <p className="text-slate-400 mt-2">

                        All AI Reviews

                    </p>

                </div>

                {

                    loading ?

                        <p>Loading...</p>

                        :

                        history.length === 0 ?

                            <p>No history available.</p>

                            :

                            <div className="space-y-5">

                                {

                                    history.map(review => (

                                        <HistoryCard
                                            key={review.id}
                                            review={review}
                                        />

                                    ))

                                }

                            </div>

                }

            </div>

        </MainLayout>

    );

}

export default History;