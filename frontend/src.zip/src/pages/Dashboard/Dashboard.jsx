import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

import MainLayout from "../../layouts/MainLayout";
import RepositoryCard from "../../components/RepositoryCard/RepositoryCard";
import { getRepositories } from "../../services/repositoryService";

function Dashboard() {

    const [repositories, setRepositories] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");
    const [search, setSearch] = useState("");

    const navigate = useNavigate();

    useEffect(() => {
        loadRepositories();
    }, []);

    async function loadRepositories() {

        try {

            const data = await getRepositories();

            setRepositories(Array.isArray(data) ? data : []);

        } catch (err) {

            console.error(err);

            toast.error("Unable to load repositories.");

            setError("Unable to load repositories.");

        } finally {

            setLoading(false);

        }

    }

    const filteredRepositories = repositories.filter((repo) =>
        repo.name.toLowerCase().includes(search.toLowerCase())
    );

    return (

        <MainLayout>

            <div className="p-10">

                {/* Header */}

                <div className="flex flex-col md:flex-row justify-between items-center gap-6 mb-10">

                    <div>

                        <h1 className="text-5xl font-extrabold">

                            Your Repositories

                        </h1>

                        <p className="text-slate-400 mt-2">

                            Select a repository to analyze with AI.

                        </p>

                    </div>

                    <input
                        type="text"
                        placeholder="Search repositories..."
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                        className="w-full md:w-80 bg-slate-900 border border-slate-700 rounded-2xl px-5 py-3 outline-none focus:border-blue-500 transition"
                    />

                </div>

                {/* Statistics */}

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">

                    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">

                        <h3 className="text-slate-400">

                            Total Repositories

                        </h3>

                        <h1 className="text-4xl font-bold mt-3">

                            {repositories.length}

                        </h1>

                    </div>

                    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">

                        <h3 className="text-slate-400">

                            Showing

                        </h3>

                        <h1 className="text-4xl font-bold mt-3">

                            {filteredRepositories.length}

                        </h1>

                    </div>

                    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">

                        <h3 className="text-slate-400">

                            AI Status

                        </h3>

                        <h1 className="text-2xl font-bold mt-4 text-green-400">

                            Ready

                        </h1>

                    </div>

                </div>

                {/* Loading */}

                {loading && (

                    <div className="text-center py-20">

                        <h2 className="text-2xl animate-pulse">

                            Loading repositories...

                        </h2>

                    </div>

                )}

                {/* Error */}

                {!loading && error && (

                    <div className="text-center text-red-500 text-xl">

                        {error}

                    </div>

                )}

                {/* Empty State */}

                {!loading &&
                    !error &&
                    filteredRepositories.length === 0 && (

                        <div className="text-center py-20">

                            <h2 className="text-3xl font-bold">

                                No repositories found

                            </h2>

                            <p className="text-slate-400 mt-4">

                                Try a different search.

                            </p>

                        </div>

                    )}

                {/* Repository Cards */}

                {!loading &&
                    !error &&
                    filteredRepositories.length > 0 && (

                        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8">

                            {filteredRepositories.map((repo) => (

                                <RepositoryCard
                                    key={repo.id}
                                    name={repo.name}
                                    language={repo.language}
                                    description={repo.description}
                                    htmlUrl={repo.htmlUrl}
                                    branch={repo.defaultBranch}
                                    isPrivate={repo.private}
                                    onReview={() =>
                                        navigate(`/repository/${repo.id}`)
                                    }
                                />

                            ))}

                        </div>

                    )}

            </div>

        </MainLayout>

    );

}

export default Dashboard;