import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import MainLayout from "../../layouts/MainLayout";
import ReviewCard from "../../components/ReviewCard/ReviewCard";

import toast from "react-hot-toast";

import { runReview } from "../../services/reviewService";
import { getRepository } from "../../services/repositoryService";

function Repository() {

    const { id } = useParams();

    const navigate = useNavigate();

    const [repository, setRepository] = useState(null);

    const [reviews, setReviews] = useState([]);

    const [loadingRepository, setLoadingRepository] = useState(true);

    const [loadingReview, setLoadingReview] = useState(false);

    const [error, setError] = useState("");

    useEffect(() => {

        loadRepository();

    }, [id]);

    async function loadRepository() {

        try {

            const data = await getRepository(id);

            setRepository(data);

        }

        catch (e) {

            console.error(e);

            toast.error("Unable to load repository.");

            setError("Unable to load repository.");

        }

        finally {

            setLoadingRepository(false);

        }

    }
    async function handleReview() {

        try {

            setLoadingReview(true);

            setError("");

            const data = await runReview(id);

            setReviews(data);

            toast.success("AI Review completed successfully.");

        }

        catch (e) {

            console.error(e);

            toast.error("Unable to generate AI review.");

            setError("Unable to generate review.");

        }

        finally {

            setLoadingReview(false);

        }

    }

    return(

        <MainLayout>

            <div className="p-10">

                <div className="mb-10">

                    <h1 className="text-5xl font-bold">

                        AI Review Results

                    </h1>

                    <button

                        onClick={() => navigate(`/history`)}

                        className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700"

                    >

                        View History

                    </button>

                    <p className="text-slate-400 mt-3">

                        Repository analysis completed.

                    </p>

                </div>

                {loadingReview && (

                    <div className="bg-slate-900 rounded-3xl p-10 text-center">

                        <h2 className="text-3xl font-bold">

                            🤖 AI is reviewing your repository...

                        </h2>

                        <div className="mt-8 w-full h-3 rounded-full bg-slate-800 overflow-hidden">

                            <div className="h-full w-2/3 bg-blue-500 animate-pulse"/>

                        </div>

                    </div>

                )}

                {error && (

                    <div className="text-red-500">

                        {error}

                    </div>

                )}

                <div className="bg-slate-900 rounded-3xl border border-slate-800 p-8 mb-10">

                    <div className="flex justify-between items-center">

                        <div>

                            <h2 className="text-3xl font-bold">

                                Overall AI Analysis

                            </h2>

                            <p className="text-slate-400 mt-2">

                                Repository quality overview

                            </p>

                        </div>

                        <div className="text-right">

                            <h1 className="text-5xl font-black text-green-400">

                                9.2

                            </h1>

                            <p className="text-slate-400">

                                /10

                            </p>

                        </div>

                    </div>

                    <div className="mt-8 h-4 rounded-full bg-slate-800 overflow-hidden">

                        <div className="h-full w-[92%] bg-gradient-to-r from-green-500 via-lime-400 to-green-500"/>

                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">

                        <div className="bg-slate-900 rounded-2xl p-6">

                            <h3 className="text-slate-400">

                                Files Reviewed

                            </h3>

                            <h1 className="text-4xl font-bold mt-3">

                                {reviews.length}

                            </h1>

                        </div>

                        <div className="bg-slate-900 rounded-2xl p-6">

                            <h3 className="text-slate-400">

                                Critical Issues

                            </h3>

                            <h1 className="text-4xl font-bold mt-3 text-red-400">

                                0

                            </h1>

                        </div>

                        <div className="bg-slate-900 rounded-2xl p-6">

                            <h3 className="text-slate-400">

                                Suggestions

                            </h3>

                            <h1 className="text-4xl font-bold mt-3 text-yellow-400">

                                {reviews.length * 2}

                            </h1>

                        </div>

                    </div>

                </div>

                <div className="space-y-8">

                    {reviews.map((review,index)=>(

                        <ReviewCard

                            key={index}

                            review={review}

                        />

                    ))}

                </div>

            </div>

        </MainLayout>

    );

}

export default Repository;